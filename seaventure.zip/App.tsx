import React from 'react';
import { GameInterface } from './components/GameInterface';

function App() {
  return (
    <GameInterface />
  );
}

export default App;